package org.leavesmc.leaves.protocol.syncmatica;

public enum MessageType {
    SUCCESS,
    INFO,
    WARNING,
    ERROR
}
