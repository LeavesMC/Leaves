package org.leavesmc.leaves.region.linear;

public enum LinearVersion {
    V1, V2
}
